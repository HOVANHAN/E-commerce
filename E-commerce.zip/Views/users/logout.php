<body>
    <?php
    include_once("../blocks/header.php");
    ?>
    <P> You have been logged out</P>
    <?php
    include_once("../blocks/footer.php");
    ?>
</body>
<?php
define("HOST", "localhost");
define("DB", "db_furnithreedots");
define("USER", "root");
define("PASSWORD", "");

<?php
define("HOST", "localhost:3307");
define("DB", "db_furnithreedots");
define("USER", "root");
define("PASSWORD", "");
